import { FC } from 'react';
import AuthPageLogin from './login';
type Props = {};
const AuthPage: FC<Props> = () => {
    return  <AuthPageLogin/>
}

export default AuthPage;