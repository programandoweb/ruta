import { NextPage } from 'next'

const ResumeInventory: NextPage = () => {
  return <div></div>
}

export default ResumeInventory