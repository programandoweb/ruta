import { NextPage } from 'next'

const PageReport: NextPage = () => {
  return <div></div>
}

export default PageReport;