import { NextPage } from 'next'
import CSRCampaignsSend from './CSRCampaignsSend'
const PageCampaignsSend: NextPage = () => {
  return  <CSRCampaignsSend/>
}

export default PageCampaignsSend