import { NextPage } from 'next'
import CampaignFormComponent from './Component'
const Page: NextPage = (props) => {
  return  <CampaignFormComponent {...props}/>
}

export default Page