import NotFound from "@/components/CustomErros/NotFoundPage";

function NotFoundPage404() {
	return <NotFound heading={"ERROR"} content="No podemos encontrar esta página"/>
}

export default NotFoundPage404;