export const saleStatusOptions = [
    { label: 'En Espera', value: 'En Espera' },
    { label: 'Finalizado', value: 'Finalizado' },
  ];
  
  export const paymentStatusOptions = [
    { label: 'En Espera', value: 'En Espera' },
    { label: 'Débito', value: 'Débito' },
    { label: 'Parcial', value: 'Parcial' },
    { label: 'Pagado', value: 'Pagado' },
  ];