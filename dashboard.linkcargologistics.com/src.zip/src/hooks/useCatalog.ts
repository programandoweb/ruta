/**
 * ---------------------------------------------------
 *  Desarrollado por: Jorge Méndez - Programandoweb
 *  Correo: lic.jorgemendez@gmail.com
 *  Celular: 3115000926
 *  website: Programandoweb.net
 *  Proyecto: Ivoolve
 * ---------------------------------------------------
 */

import { useEffect, useState } from 'react';
import { db, Product, Category } from '@/db/indexedDB';
import useFormData from '@/hooks/useFormDataNew';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

export const useCatalog = () => {
  const formData = useFormData(false, false, false);
  const isOnline = useNetworkStatus();
  const [products, setProducts]   = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [byDay, setByDay]           = useState<any[]>([]);

  useEffect(() => {
    const load = async () => {
      if (isOnline) {
        try {
          const res: any = await formData.handleRequest(
            formData.backend + '/open/getInit'
          );

          if (res?.menu) {
            await db.products.clear();
            await db.products.bulkAdd(
              res.menu.map((p: any) => ({
                id: p.id,
                name: p.name,
                price: Number(p.price),
                category: p.product_category?.name || '',
                stock: Number(p.stock) ?? 0,
              }))
            );
            setProducts(res.menu);
          }

          if (res?.categories) {
            await db.categories.clear();
            await db.categories.bulkAdd(res.categories);
            setCategories(res.categories);
          }

          if (res?.byDay) {
            setByDay(res?.byDay);
          }
        } catch (err) {
          console.error('❌ Error cargando desde backend, uso IndexedDB', err);
          setProducts(await db.products.toArray());
          setCategories(await db.categories.toArray());
        }
      } else {
        // 🚨 Offline → usar IndexedDB
        setProducts(await db.products.toArray());
        setCategories(await db.categories.toArray());
      }
    };

    load();
  }, [isOnline]);

  return { byDay, products, categories, isOnline };
};
