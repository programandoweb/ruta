// interfaces.tsx
import { ReactNode } from 'react';

export interface Tab {
  label: string;
  component: ReactNode;
}
