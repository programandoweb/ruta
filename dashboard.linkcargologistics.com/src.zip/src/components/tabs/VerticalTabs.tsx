const VerticalTabs = () => {
    return (
        <div>
            
        </div>
    )
}

export default VerticalTabs