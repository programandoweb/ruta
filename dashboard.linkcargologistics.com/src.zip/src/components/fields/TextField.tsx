import React, { useEffect, useState } from "react";

type ChangeEventHandler = (event: React.ChangeEvent<HTMLTextAreaElement>) => void;

type TextFieldProps = {
  setInputs?: (value: any) => void;
  prefixed?: string;
  label?: string;
  id?: string;
  extra?: string;
  placeholder?: string;
  cols?: number;
  rows?: number;
  state?: 'error' | 'success' | string;
  disabled?: boolean;
  defaultValue?: any;
  name?: string;
  height?:number;
};

type FormData = {
  [key: string]: any;
};

const TextField: React.FC<TextFieldProps> = (props) => {
  const { setInputs, label, id, extra, placeholder, cols, rows, state, disabled, defaultValue, name , height} = props;
  const [value, setValue] = useState<FormData>({ [name || '']: defaultValue || '' });

  const onChange: ChangeEventHandler = (e) => {
    const newValue = e.target.value;
    setValue((prevValue) => ({ ...prevValue, [name || '']: newValue }));

    if (setInputs) {
      setInputs((prevFormData: any) => ({
        ...prevFormData,
        [e.target.name]: newValue,
      }));
    }
  };

  useEffect(() => {
    if (defaultValue && name) {
      setValue((prevValue) => ({ ...prevValue, [name]: defaultValue }));
    }
  }, [defaultValue, name]);

  return (
    <div className={`${extra}`}>
      <label
        htmlFor={id}
        className="ml-3 mb-2 text-sm font-bold text-navy-700 dark:text-white"
      >
        {label}
      </label>      
      <textarea
        value={value[name || '']}
        name={name}
        onChange={onChange}
        disabled={disabled}
        cols={cols}
        rows={rows}
        placeholder={placeholder}
        className={` h-[${height?.toString()}px] resize-none flex w-full items-center justify-center rounded-xl border bg-white/0 pl-3 pt-3 text-sm outline-none ${
          disabled === true
            ? "!border-none !bg-gray-100 dark:!bg-white/5 dark:placeholder:!text-[rgba(255,255,255,0.15)]"
            : state === "error"
            ? "!border-red-500 text-red-500 placeholder:text-red-500 dark:!border-red-400 dark:!text-red-400 dark:placeholder:!text-red-400"
            : state === "success"
            ? "!border-green-500 text-green-500 placeholder:text-green-500 dark:!border-green-400 dark:!text-green-400 dark:placeholder:!text-green-400"
            : "border-gray-200 dark:!border-white/10 dark:text-white"
        }`}
        id={id}
      />      
    </div>
  );
}

export default TextField;
