'use client'
import { formatearMonto } from "@/utils/fuctions"
import { Fragment } from "react"
import { FiPlus } from "react-icons/fi"

interface Props {
  products: any[]
  selectedProduct: number | ''
  setSelectedProduct: (id: number | '') => void
  quantity: number
  setQuantity: (q: number) => void
  description: string
  setDescription: (d: string) => void
  descriptionsList: string[]
  handleAdd: () => void
}

const ProductInputs: React.FC<Props> = ({
  products, selectedProduct, setSelectedProduct,
  quantity, setQuantity, description, setDescription,
  descriptionsList, handleAdd
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-4">
      <select
        value={selectedProduct}
        onChange={e => setSelectedProduct(Number(e.target.value))}
        className="border rounded-lg px-3 py-2 sm:col-span-4"
      >
        <option value="">Seleccione un producto</option>
        {products.map((p: any) => (
          <option key={p.id} value={p.id}>
            {p.name} {p.short_description?<Fragment>{p.short_description}</Fragment>:<Fragment></Fragment>} - {p.product_category?.name} (${ formatearMonto(p.price)})
          </option>
        ))}
      </select>      
      <input
        type="number"
        min={1}
        value={quantity}
        onChange={e => setQuantity(Number(e.target.value))}
        className="border rounded-lg px-3 py-2"
        placeholder="Cantidad"
      />
      <input
        type="text"
        list="descriptions"
        value={description}
        onChange={e => setDescription(e.target.value)}
        className="border rounded-lg px-3 py-2 sm:col-span-2"
        placeholder="Descripción (ej: Carlos, Chica rubia)"
      />
      <datalist id="descriptions">
        {descriptionsList.map((desc, idx) => (
          <option key={idx} value={desc} />
        ))}
      </datalist>
      <button
        onClick={handleAdd}
        className="bg-blue-600 text-white p-2 rounded-full shadow hover:bg-blue-700 flex justify-center items-center"
      >
        <FiPlus size={20} />
      </button>
    </div>
  )
}

export default ProductInputs
