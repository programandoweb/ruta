import Logo from "@/components/logo";

const Cart=()=>{
    return      <div className="flex justify-center items-center ">
                    <div className="text-center">
                        <div className="p-2">
                            <Logo />
                        </div>
                    </div>
                </div>
  
}
export default Cart;