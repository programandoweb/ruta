export interface interfaceIndex {
    setIngredients?: any;
    ingredients?:any;
    dataset?:any;
    setDataset?:any;
}
