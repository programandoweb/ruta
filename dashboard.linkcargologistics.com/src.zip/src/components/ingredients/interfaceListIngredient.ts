export interface ListIngredientProps {
    dataset: any[];
    setDataset?: any;
    setIngredients?: any;
    ingredients?:any;
}
