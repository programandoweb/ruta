
import GroupIcon from '@mui/icons-material/PeopleOutlineOutlined';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
//import CoPresentIcon from '@mui/icons-material/CoPresentOutlined';
import HttpsOutlinedIcon from '@mui/icons-material/HttpsOutlined';
import CalculateOutlinedIcon from '@mui/icons-material/CalculateOutlined';
import Face3OutlinedIcon from '@mui/icons-material/Face3Outlined';
import HailOutlinedIcon from '@mui/icons-material/HailOutlined';

export const assignRol = {
    Admin:false,
    Residente:false,
    Usuario:false,
    Vigilante:false,
    Visitante:false,  
}
    